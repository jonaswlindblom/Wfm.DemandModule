export type Stream = {
  id: string;
  name: string;
  sourceSystem: string;
  industry: string;
};

export type Activity = {
  id: string;
  code: string;
  name: string;
  isActive: boolean;
};

export type MappingVersion = {
  id: string;
  streamId: string;
  versionNumber: number;
  name: string;
  createdAtUtc: string;
};

export type MappingRule = {
  id: string;
  mappingVersionId: string;
  eventType: string;
  conditionExpression?: string | null;
  name: string;
  sortOrder: number;
};

export type MappingRuleActivity = {
  id: string;
  mappingRuleId: string;
  activityId: string;
  baseHours: number;
  unitExpression?: string | null;
  perUnitHours: number;
  multiplierExpression?: string | null;
};

export type LatestMappingResponse = {
  version: MappingVersion;
  rules: MappingRule[];
  ruleActivities: MappingRuleActivity[];
};

export type SimulationCreateResponse = { simulationId: string };

export type WorkloadBucket = {
  id: string;
  simulationRunId: string;
  activityId: string;
  intervalStartUtc: string;
  intervalEndUtc: string;
  hours: number;
  explanationJson: string;
};
