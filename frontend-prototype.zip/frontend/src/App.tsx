import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { Container, Box, Button, Stack } from "@mui/material";
import TopBar from "./components/TopBar";
import MappingEditorPage from "./pages/MappingEditorPage";
import SimulationPage from "./pages/SimulationPage";

export default function App() {
  return (
    <BrowserRouter>
      <TopBar />
      <Box sx={{ borderBottom: 1, borderColor: "divider", bgcolor: "background.paper" }}>
        <Container sx={{ py: 1 }}>
          <Stack direction="row" spacing={1}>
            <Button component={Link} to="/" variant="outlined">Mapping Editor</Button>
            <Button component={Link} to="/simulation" variant="outlined">Simulation</Button>
          </Stack>
        </Container>
      </Box>
      <Container sx={{ py: 3 }}>
        <Routes>
          <Route path="/" element={<MappingEditorPage />} />
          <Route path="/simulation" element={<SimulationPage />} />
        </Routes>
      </Container>
    </BrowserRouter>
  );
}
